<?php 
	$con=mysqli_connect("localhost","root","","db_birthday_reminder");
?>